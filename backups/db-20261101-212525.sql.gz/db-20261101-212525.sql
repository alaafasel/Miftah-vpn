--
-- PostgreSQL database dump
--

\restrict OF1b65kfcdRRmThqv9Belr0S038fcXXkl9gatU8Zagm9XlUxwi3YJY89wQZ0xQh

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    password_hash character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login_at timestamp with time zone
);


ALTER TABLE public.admin_users OWNER TO miftah;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: miftah
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_users_id_seq OWNER TO miftah;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: miftah
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO miftah;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    admin_id integer,
    action character varying(64) NOT NULL,
    entity_type character varying(64),
    entity_id character varying(64),
    details jsonb,
    ip character varying(45),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO miftah;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: miftah
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO miftah;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: miftah
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: config_versions; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.config_versions (
    id integer NOT NULL,
    config_id integer NOT NULL,
    version integer NOT NULL,
    content jsonb NOT NULL,
    note text,
    is_current boolean DEFAULT false NOT NULL,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.config_versions OWNER TO miftah;

--
-- Name: config_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: miftah
--

CREATE SEQUENCE public.config_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.config_versions_id_seq OWNER TO miftah;

--
-- Name: config_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: miftah
--

ALTER SEQUENCE public.config_versions_id_seq OWNED BY public.config_versions.id;


--
-- Name: devices; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    license_id integer NOT NULL,
    public_key text NOT NULL,
    key_fingerprint character varying(64) NOT NULL,
    model character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    bound_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone,
    unbound_at timestamp with time zone
);


ALTER TABLE public.devices OWNER TO miftah;

--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: miftah
--

CREATE SEQUENCE public.devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.devices_id_seq OWNER TO miftah;

--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: miftah
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: license_proxy_access; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.license_proxy_access (
    license_id integer NOT NULL,
    proxy_id integer NOT NULL
);


ALTER TABLE public.license_proxy_access OWNER TO miftah;

--
-- Name: licenses; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.licenses (
    id integer NOT NULL,
    code_hash character varying(64) NOT NULL,
    uuid_id integer NOT NULL,
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.licenses OWNER TO miftah;

--
-- Name: licenses_id_seq; Type: SEQUENCE; Schema: public; Owner: miftah
--

CREATE SEQUENCE public.licenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.licenses_id_seq OWNER TO miftah;

--
-- Name: licenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: miftah
--

ALTER SEQUENCE public.licenses_id_seq OWNED BY public.licenses.id;


--
-- Name: proxies; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.proxies (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    address character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.proxies OWNER TO miftah;

--
-- Name: proxies_id_seq; Type: SEQUENCE; Schema: public; Owner: miftah
--

CREATE SEQUENCE public.proxies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.proxies_id_seq OWNER TO miftah;

--
-- Name: proxies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: miftah
--

ALTER SEQUENCE public.proxies_id_seq OWNED BY public.proxies.id;


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.subscriptions (
    id integer NOT NULL,
    license_id integer NOT NULL,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO miftah;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: miftah
--

CREATE SEQUENCE public.subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subscriptions_id_seq OWNER TO miftah;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: miftah
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: uuids; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.uuids (
    id integer NOT NULL,
    value uuid NOT NULL,
    label character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.uuids OWNER TO miftah;

--
-- Name: uuids_id_seq; Type: SEQUENCE; Schema: public; Owner: miftah
--

CREATE SEQUENCE public.uuids_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.uuids_id_seq OWNER TO miftah;

--
-- Name: uuids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: miftah
--

ALTER SEQUENCE public.uuids_id_seq OWNED BY public.uuids.id;


--
-- Name: xray_configs; Type: TABLE; Schema: public; Owner: miftah
--

CREATE TABLE public.xray_configs (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    draft jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.xray_configs OWNER TO miftah;

--
-- Name: xray_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: miftah
--

CREATE SEQUENCE public.xray_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.xray_configs_id_seq OWNER TO miftah;

--
-- Name: xray_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: miftah
--

ALTER SEQUENCE public.xray_configs_id_seq OWNED BY public.xray_configs.id;


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: config_versions id; Type: DEFAULT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.config_versions ALTER COLUMN id SET DEFAULT nextval('public.config_versions_id_seq'::regclass);


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: licenses id; Type: DEFAULT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.licenses ALTER COLUMN id SET DEFAULT nextval('public.licenses_id_seq'::regclass);


--
-- Name: proxies id; Type: DEFAULT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.proxies ALTER COLUMN id SET DEFAULT nextval('public.proxies_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: uuids id; Type: DEFAULT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.uuids ALTER COLUMN id SET DEFAULT nextval('public.uuids_id_seq'::regclass);


--
-- Name: xray_configs id; Type: DEFAULT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.xray_configs ALTER COLUMN id SET DEFAULT nextval('public.xray_configs_id_seq'::regclass);


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.admin_users (id, username, password_hash, is_active, created_at, last_login_at) FROM stdin;
1	alaa	$argon2id$v=19$m=65536,t=3,p=4$dMrtRri7YYChSUemsRQqMg$tTo873J6FhbVcwWe9+g8gPRCGYVO6aR1n4JGDe4yukc	t	2026-11-01 18:48:45.65788+00	2026-11-01 18:53:05.795814+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.alembic_version (version_num) FROM stdin;
73a404055473
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.audit_logs (id, admin_id, action, entity_type, entity_id, details, ip, created_at) FROM stdin;
1	\N	admin_login_failed	admin	alaa	\N	172.18.0.1	2026-11-01 18:52:48.490987+00
2	1	admin_login_ok	admin	alaa	\N	172.18.0.1	2026-11-01 18:53:05.731637+00
3	\N	admin_login_failed	admin	alaa	\N	172.18.0.1	2026-11-01 18:54:46.758326+00
4	\N	admin_login_failed	admin	alaa	\N	172.18.0.1	2026-11-01 18:54:46.837186+00
5	\N	admin_login_failed	admin	alaa	\N	172.18.0.1	2026-11-01 18:54:46.917775+00
6	\N	admin_login_failed	admin	alaa	\N	172.18.0.1	2026-11-01 18:54:46.993782+00
\.


--
-- Data for Name: config_versions; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.config_versions (id, config_id, version, content, note, is_current, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.devices (id, license_id, public_key, key_fingerprint, model, is_active, bound_at, last_seen_at, unbound_at) FROM stdin;
\.


--
-- Data for Name: license_proxy_access; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.license_proxy_access (license_id, proxy_id) FROM stdin;
\.


--
-- Data for Name: licenses; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.licenses (id, code_hash, uuid_id, status, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: proxies; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.proxies (id, name, address, is_active, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.subscriptions (id, license_id, starts_at, ends_at, status, created_at) FROM stdin;
\.


--
-- Data for Name: uuids; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.uuids (id, value, label, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: xray_configs; Type: TABLE DATA; Schema: public; Owner: miftah
--

COPY public.xray_configs (id, name, draft, created_at, updated_at) FROM stdin;
\.


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: miftah
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 1, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: miftah
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 6, true);


--
-- Name: config_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: miftah
--

SELECT pg_catalog.setval('public.config_versions_id_seq', 1, false);


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: miftah
--

SELECT pg_catalog.setval('public.devices_id_seq', 1, false);


--
-- Name: licenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: miftah
--

SELECT pg_catalog.setval('public.licenses_id_seq', 1, false);


--
-- Name: proxies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: miftah
--

SELECT pg_catalog.setval('public.proxies_id_seq', 1, false);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: miftah
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 1, false);


--
-- Name: uuids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: miftah
--

SELECT pg_catalog.setval('public.uuids_id_seq', 1, false);


--
-- Name: xray_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: miftah
--

SELECT pg_catalog.setval('public.xray_configs_id_seq', 1, false);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_username_key; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_username_key UNIQUE (username);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: config_versions config_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.config_versions
    ADD CONSTRAINT config_versions_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: license_proxy_access license_proxy_access_pkey; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.license_proxy_access
    ADD CONSTRAINT license_proxy_access_pkey PRIMARY KEY (license_id, proxy_id);


--
-- Name: licenses licenses_code_hash_key; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_code_hash_key UNIQUE (code_hash);


--
-- Name: licenses licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_pkey PRIMARY KEY (id);


--
-- Name: proxies proxies_pkey; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.proxies
    ADD CONSTRAINT proxies_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: config_versions uq_config_version; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.config_versions
    ADD CONSTRAINT uq_config_version UNIQUE (config_id, version);


--
-- Name: uuids uuids_pkey; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.uuids
    ADD CONSTRAINT uuids_pkey PRIMARY KEY (id);


--
-- Name: uuids uuids_value_key; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.uuids
    ADD CONSTRAINT uuids_value_key UNIQUE (value);


--
-- Name: xray_configs xray_configs_name_key; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.xray_configs
    ADD CONSTRAINT xray_configs_name_key UNIQUE (name);


--
-- Name: xray_configs xray_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.xray_configs
    ADD CONSTRAINT xray_configs_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_action; Type: INDEX; Schema: public; Owner: miftah
--

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: miftah
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_devices_key_fingerprint; Type: INDEX; Schema: public; Owner: miftah
--

CREATE INDEX ix_devices_key_fingerprint ON public.devices USING btree (key_fingerprint);


--
-- Name: ix_devices_license_id; Type: INDEX; Schema: public; Owner: miftah
--

CREATE INDEX ix_devices_license_id ON public.devices USING btree (license_id);


--
-- Name: ix_licenses_uuid_id; Type: INDEX; Schema: public; Owner: miftah
--

CREATE INDEX ix_licenses_uuid_id ON public.licenses USING btree (uuid_id);


--
-- Name: ix_subscriptions_license_id; Type: INDEX; Schema: public; Owner: miftah
--

CREATE INDEX ix_subscriptions_license_id ON public.subscriptions USING btree (license_id);


--
-- Name: uq_devices_one_active_per_license; Type: INDEX; Schema: public; Owner: miftah
--

CREATE UNIQUE INDEX uq_devices_one_active_per_license ON public.devices USING btree (license_id) WHERE is_active;


--
-- Name: uq_one_current_version_per_config; Type: INDEX; Schema: public; Owner: miftah
--

CREATE UNIQUE INDEX uq_one_current_version_per_config ON public.config_versions USING btree (config_id) WHERE is_current;


--
-- Name: audit_logs audit_logs_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: config_versions config_versions_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.config_versions
    ADD CONSTRAINT config_versions_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.xray_configs(id) ON DELETE CASCADE;


--
-- Name: config_versions config_versions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.config_versions
    ADD CONSTRAINT config_versions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: devices devices_license_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_license_id_fkey FOREIGN KEY (license_id) REFERENCES public.licenses(id) ON DELETE CASCADE;


--
-- Name: license_proxy_access license_proxy_access_license_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.license_proxy_access
    ADD CONSTRAINT license_proxy_access_license_id_fkey FOREIGN KEY (license_id) REFERENCES public.licenses(id) ON DELETE CASCADE;


--
-- Name: license_proxy_access license_proxy_access_proxy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.license_proxy_access
    ADD CONSTRAINT license_proxy_access_proxy_id_fkey FOREIGN KEY (proxy_id) REFERENCES public.proxies(id) ON DELETE CASCADE;


--
-- Name: licenses licenses_uuid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_uuid_id_fkey FOREIGN KEY (uuid_id) REFERENCES public.uuids(id) ON DELETE RESTRICT;


--
-- Name: subscriptions subscriptions_license_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: miftah
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_license_id_fkey FOREIGN KEY (license_id) REFERENCES public.licenses(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict OF1b65kfcdRRmThqv9Belr0S038fcXXkl9gatU8Zagm9XlUxwi3YJY89wQZ0xQh

